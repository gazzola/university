import java.lang.Exception;

class FileException extends Exception{
	public FileException(String message){
		super(message);
	}
}