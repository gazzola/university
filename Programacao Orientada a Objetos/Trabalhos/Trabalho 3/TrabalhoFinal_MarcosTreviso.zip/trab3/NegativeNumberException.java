import java.lang.Exception;

class NegativeNumberException extends Exception{
	public NegativeNumberException(String message){
		super(message);
	}
}